from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

from owen_gateway.config import BusConfig, OwenGatewayConfig, PointConfig
from owen_gateway.modbus_server import ModbusPublisher
from owen_gateway.protocol import decode_payload, hash_parameter_name
from owen_gateway.serial_client import OwenSerialClient


STATUS_OK = 1
STATUS_DEGRADED = 2
STATUS_OFFLINE = 3
STATUS_PROTOCOL_ERROR = 4

ERROR_NONE = 0
ERROR_TIMEOUT = 1
ERROR_BAD_FLAG = 2
ERROR_HASH_MISMATCH = 3
ERROR_DECODE = 4
ERROR_IO = 5

CHANNEL_DISABLED = 0
CHANNEL_OK = 1
CHANNEL_STALE = 2
CHANNEL_COMM_ERROR = 3
CHANNEL_PROTOCOL_ERROR = 4
CHANNEL_FAILED = 5


@dataclass(slots=True)
class PointState:
    last_time_mark: int | None = None
    unchanged_mark_streak: int = 0
    consecutive_failures: int = 0
    channel_status: int = CHANNEL_COMM_ERROR
    recovery_skip_cycles: int = 0


class OwenGatewayService:
    def __init__(self, config: OwenGatewayConfig) -> None:
        self.config = config
        self.logger = logging.getLogger("owen_gateway")
        self.serial_clients = {
            bus.name: OwenSerialClient(bus.serial) for bus in config.buses
        }
        self.buses = {bus.name: bus for bus in config.buses}
        self.points_by_bus = _group_points_by_bus(config.points)
        self.modbus = ModbusPublisher(config)
        self.success_counter = 0
        self.timeout_counter = 0
        self.protocol_error_counter = 0
        self.poll_cycle_counter = 0
        self.last_error_code = ERROR_NONE
        self.bus_statuses = {bus.name: STATUS_OFFLINE for bus in config.buses}
        self.point_states = {point.name: PointState() for point in config.points}
        self._state_lock = asyncio.Lock()

    async def run(self) -> None:
        await self.modbus.start()
        self.modbus.publish_status(STATUS_OFFLINE)
        self.modbus.publish_telemetry(
            last_error_code=self.last_error_code,
            success_counter=self.success_counter,
            timeout_counter=self.timeout_counter,
            protocol_error_counter=self.protocol_error_counter,
            poll_cycle_counter=self.poll_cycle_counter,
        )
        for bus in self.config.buses:
            self.serial_clients[bus.name].connect()
            self.logger.info(
                "bus started: name=%s serial=%s %s,%s%s%s",
                bus.name,
                bus.serial.port,
                bus.serial.baudrate,
                bus.serial.bytesize,
                bus.serial.parity,
                bus.serial.stopbits,
            )
        self.logger.info(
            "modbus started: %s:%s",
            self.config.modbus.host,
            self.config.modbus.port,
        )
        try:
            tasks = [
                asyncio.create_task(self._poll_bus_loop(bus))
                for bus in self.config.buses
            ]
            await asyncio.gather(*tasks)
        finally:
            self.modbus.publish_status(STATUS_OFFLINE)
            for client in self.serial_clients.values():
                client.close()
            await self.modbus.stop()

    async def _poll_bus_loop(self, bus: BusConfig) -> None:
        while True:
            await self._poll_bus_once(bus, self.points_by_bus.get(bus.name, []))
            await asyncio.sleep(bus.poll_interval_ms / 1000)

    async def _poll_bus_once(self, bus: BusConfig, points: list[PointConfig]) -> None:
        failures = 0
        protocol_failures = 0
        last_error_code = ERROR_NONE
        if not points:
            await self._record_bus_result(bus.name, STATUS_OK, last_error_code)
            return

        for point in points:
            point_state = self.point_states[point.name]
            if point_state.recovery_skip_cycles > 0:
                point_state.recovery_skip_cycles -= 1
                self.modbus.publish_point_metadata(
                    point,
                    channel_status=CHANNEL_FAILED,
                )
                self.logger.debug(
                    "skipping failed point bus=%s %s remaining_skip_cycles=%s",
                    bus.name,
                    point.name,
                    point_state.recovery_skip_cycles,
                )
                failures += 1
                continue
            frame = None
            try:
                request, response, frame = await asyncio.to_thread(
                    self.serial_clients[bus.name].exchange,
                    point.address,
                    point.parameter,
                )
                if self.config.diagnostics:
                    self.logger.info(
                        "diag bus=%s point=%s request=%s response=%s",
                        bus.name,
                        point.name,
                        request.hex(" "),
                        response.hex(" "),
                    )
                if frame.request:
                    raise RuntimeError(
                        f"invalid response for {point.name}: request flag is set in response"
                    )
                expected_hash = hash_parameter_name(point.parameter)
                if frame.parameter_hash != expected_hash:
                    raise RuntimeError(
                        f"invalid response for {point.name}: hash mismatch "
                        f"0x{frame.parameter_hash:04X} != 0x{expected_hash:04X}"
                    )
                time_mark = _extract_time_mark(frame.payload)
                if frame.payload == b"":
                    point_state.consecutive_failures = 0
                    point_state.unchanged_mark_streak = 0
                    point_state.channel_status = CHANNEL_DISABLED
                    self.modbus.publish_point_metadata(
                        point,
                        time_mark=None,
                        channel_status=CHANNEL_DISABLED,
                    )
                    self.logger.info(
                        "empty payload bus=%s %s address=%s parameter=%s",
                        bus.name,
                        point.name,
                        point.address,
                        point.parameter,
                    )
                    continue
                value = decode_payload(frame.payload, point.protocol_format)
                self.modbus.publish(point, value)
                point_state.consecutive_failures = 0
                if time_mark is None:
                    point_state.unchanged_mark_streak = 0
                    point_state.channel_status = CHANNEL_OK
                elif point_state.last_time_mark == time_mark:
                    point_state.unchanged_mark_streak += 1
                    point_state.channel_status = (
                        CHANNEL_STALE
                        if point_state.unchanged_mark_streak
                        >= self.config.health.stale_after_cycles
                        else CHANNEL_OK
                    )
                else:
                    point_state.last_time_mark = time_mark
                    point_state.unchanged_mark_streak = 0
                    point_state.channel_status = CHANNEL_OK
                self.modbus.publish_point_metadata(
                    point,
                    time_mark=time_mark,
                    channel_status=point_state.channel_status,
                )
                async with self._state_lock:
                    self.success_counter = _inc_counter(self.success_counter)
                self.logger.debug(
                    "published bus=%s %s=%r from address=%s parameter=%s to %s:%s mark=%s status=%s",
                    bus.name,
                    point.name,
                    value,
                    point.address,
                    point.parameter,
                    point.register_type,
                    point.modbus_address,
                    time_mark,
                    point_state.channel_status,
                )
            except TimeoutError:
                failures += 1
                point_state.consecutive_failures += 1
                point_state.channel_status = _failure_status(
                    point_state,
                    self.config.health.fault_after_failures,
                    self.config.health.recovery_poll_interval_cycles,
                    CHANNEL_COMM_ERROR,
                )
                self.modbus.publish_point_metadata(
                    point,
                    channel_status=point_state.channel_status,
                )
                async with self._state_lock:
                    self.timeout_counter = _inc_counter(self.timeout_counter)
                last_error_code = ERROR_TIMEOUT
                self.logger.warning(
                    "timeout reading bus=%s %s address=%s parameter=%s",
                    bus.name,
                    point.name,
                    point.address,
                    point.parameter,
                )
            except (ValueError, RuntimeError):
                failures += 1
                protocol_failures += 1
                point_state.consecutive_failures += 1
                point_state.channel_status = _failure_status(
                    point_state,
                    self.config.health.fault_after_failures,
                    self.config.health.recovery_poll_interval_cycles,
                    CHANNEL_PROTOCOL_ERROR,
                )
                self.modbus.publish_point_metadata(
                    point,
                    channel_status=point_state.channel_status,
                )
                async with self._state_lock:
                    self.protocol_error_counter = _inc_counter(self.protocol_error_counter)
                last_error_code = _map_protocol_error(point, frame)
                self.logger.exception(
                    "protocol error for bus=%s %s address=%s parameter=%s",
                    bus.name,
                    point.name,
                    point.address,
                    point.parameter,
                )
            except Exception:
                failures += 1
                point_state.consecutive_failures += 1
                point_state.channel_status = _failure_status(
                    point_state,
                    self.config.health.fault_after_failures,
                    self.config.health.recovery_poll_interval_cycles,
                    CHANNEL_COMM_ERROR,
                )
                self.modbus.publish_point_metadata(
                    point,
                    channel_status=point_state.channel_status,
                )
                last_error_code = ERROR_IO
                self.logger.exception(
                    "poll failed for bus=%s %s address=%s parameter=%s",
                    bus.name,
                    point.name,
                    point.address,
                    point.parameter,
                )

        if failures == 0:
            bus_status = STATUS_OK
        elif protocol_failures == len(points):
            bus_status = STATUS_PROTOCOL_ERROR
        elif failures == len(points):
            bus_status = STATUS_OFFLINE
        else:
            bus_status = STATUS_DEGRADED
        await self._record_bus_result(bus.name, bus_status, last_error_code)

    async def _record_bus_result(
        self,
        bus_name: str,
        bus_status: int,
        last_error_code: int,
    ) -> None:
        async with self._state_lock:
            self.bus_statuses[bus_name] = bus_status
            self.last_error_code = last_error_code
            self.poll_cycle_counter = _inc_counter(self.poll_cycle_counter)
            self.modbus.publish_status(_aggregate_status(self.bus_statuses.values()))
            self.modbus.publish_telemetry(
                last_error_code=self.last_error_code,
                success_counter=self.success_counter,
                timeout_counter=self.timeout_counter,
                protocol_error_counter=self.protocol_error_counter,
                poll_cycle_counter=self.poll_cycle_counter,
            )


def _inc_counter(value: int) -> int:
    return (value + 1) & 0xFFFF


def _group_points_by_bus(points: list[PointConfig]) -> dict[str, list[PointConfig]]:
    grouped: dict[str, list[PointConfig]] = {}
    for point in points:
        grouped.setdefault(point.bus, []).append(point)
    return grouped


def _aggregate_status(statuses: object) -> int:
    status_list = list(statuses)
    if not status_list:
        return STATUS_OFFLINE
    if all(status == STATUS_OK for status in status_list):
        return STATUS_OK
    if all(status == STATUS_PROTOCOL_ERROR for status in status_list):
        return STATUS_PROTOCOL_ERROR
    if all(status == STATUS_OFFLINE for status in status_list):
        return STATUS_OFFLINE
    return STATUS_DEGRADED


def _map_protocol_error(point: object, frame: object) -> int:
    if frame is not None and getattr(frame, "request", False):
        return ERROR_BAD_FLAG
    if frame is not None and getattr(point, "parameter", None) is not None:
        expected_hash = hash_parameter_name(point.parameter)
        if getattr(frame, "parameter_hash", expected_hash) != expected_hash:
            return ERROR_HASH_MISMATCH
    return ERROR_DECODE


def _extract_time_mark(payload: bytes) -> int | None:
    if len(payload) == 6:
        return int.from_bytes(payload[4:6], "big")
    return None


def _failure_status(
    point_state: PointState,
    fault_after_failures: int,
    recovery_poll_interval_cycles: int,
    transient_status: int,
) -> int:
    if point_state.consecutive_failures >= fault_after_failures:
        point_state.recovery_skip_cycles = recovery_poll_interval_cycles - 1
        return CHANNEL_FAILED
    return transient_status
