from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from owen_gateway.encoding import register_width


VALID_PROTOCOL_FORMATS = {
    "float32",
    "int16",
    "uint16",
    "uint32",
    "raw",
}

VALID_REGISTER_TYPES = {
    "coil",
    "discrete_input",
    "holding_register",
    "input_register",
}

VALID_MODBUS_DATA_TYPES = {
    "bool",
    "uint16",
    "int16",
    "uint32",
    "int32",
    "float32",
}

MAX_BUSES = 4
MAX_DEVICES_PER_BUS = 8
MAX_TOTAL_DEVICES = 32


@dataclass(slots=True)
class SerialConfig:
    port: str
    baudrate: int
    bytesize: int
    parity: str
    stopbits: int
    timeout_ms: int
    address_bits: int = 8


@dataclass(slots=True)
class BusConfig:
    name: str
    serial: SerialConfig
    poll_interval_ms: int


@dataclass(slots=True)
class ModbusConfig:
    host: str
    port: int


@dataclass(slots=True)
class StatusConfig:
    enabled: bool
    register_type: str
    modbus_address: int
    modbus_data_type: str


@dataclass(slots=True)
class TelemetryConfig:
    enabled: bool
    register_type: str
    last_error_code_address: int
    success_counter_address: int
    timeout_counter_address: int
    protocol_error_counter_address: int
    poll_cycle_counter_address: int


@dataclass(slots=True)
class HealthConfig:
    stale_after_cycles: int
    fault_after_failures: int
    recovery_poll_interval_cycles: int


@dataclass(slots=True)
class PointConfig:
    name: str
    bus: str
    device: int
    address: int
    parameter: str
    protocol_format: str
    register_type: str
    modbus_address: int
    modbus_data_type: str
    time_mark_address: int | None = None
    channel_status_address: int | None = None


@dataclass(slots=True)
class OwenGatewayConfig:
    buses: list[BusConfig]
    diagnostics: bool
    modbus: ModbusConfig
    status: StatusConfig
    telemetry: TelemetryConfig
    health: HealthConfig
    points: list[PointConfig]


def load_config(path: str | Path) -> OwenGatewayConfig:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    buses = _load_buses(payload)
    config = OwenGatewayConfig(
        buses=buses,
        diagnostics=payload.get("diagnostics", False),
        modbus=ModbusConfig(**payload["modbus"]),
        status=StatusConfig(**payload.get("status", _default_status_config())),
        telemetry=TelemetryConfig(
            **payload.get("telemetry", _default_telemetry_config())
        ),
        health=HealthConfig(**payload.get("health", _default_health_config())),
        points=[_load_point(entry, buses) for entry in payload["points"]],
    )
    validate_config(config)
    return config


def validate_config(config: OwenGatewayConfig) -> None:
    if not config.buses:
        raise ValueError("at least one bus must be configured")
    if len(config.buses) > MAX_BUSES:
        raise ValueError(f"configured buses exceed limit: {len(config.buses)} > {MAX_BUSES}")
    bus_names: set[str] = set()
    for bus in config.buses:
        if bus.name in bus_names:
            raise ValueError(f"duplicate bus name: {bus.name}")
        bus_names.add(bus.name)
        if bus.poll_interval_ms <= 0:
            raise ValueError(f"bus {bus.name}: poll_interval_ms must be > 0")
        _validate_serial_config(bus.name, bus.serial)
    if not (1 <= config.modbus.port <= 65535):
        raise ValueError("modbus.port must be in range 1..65535")
    if config.status.enabled:
        if config.status.register_type not in VALID_REGISTER_TYPES:
            raise ValueError(
                f"unsupported status.register_type: {config.status.register_type}"
            )
        if config.status.modbus_data_type not in VALID_MODBUS_DATA_TYPES:
            raise ValueError(
                "unsupported status.modbus_data_type: "
                f"{config.status.modbus_data_type}"
            )
        if config.status.modbus_address < 0:
            raise ValueError("status.modbus_address must be >= 0")
    if config.telemetry.enabled:
        if config.telemetry.register_type not in VALID_REGISTER_TYPES:
            raise ValueError(
                f"unsupported telemetry.register_type: {config.telemetry.register_type}"
            )
        telemetry_addresses = [
            config.telemetry.last_error_code_address,
            config.telemetry.success_counter_address,
            config.telemetry.timeout_counter_address,
            config.telemetry.protocol_error_counter_address,
            config.telemetry.poll_cycle_counter_address,
        ]
        if any(address < 0 for address in telemetry_addresses):
            raise ValueError("telemetry register addresses must be >= 0")
    if config.health.stale_after_cycles < 1:
        raise ValueError("health.stale_after_cycles must be >= 1")
    if config.health.fault_after_failures < 1:
        raise ValueError("health.fault_after_failures must be >= 1")
    if config.health.recovery_poll_interval_cycles < 1:
        raise ValueError("health.recovery_poll_interval_cycles must be >= 1")

    occupied: dict[str, set[int]] = {}
    devices_per_bus: dict[str, set[int]] = {bus.name: set() for bus in config.buses}
    if config.status.enabled:
        occupied[config.status.register_type] = set(
            range(
                config.status.modbus_address,
                config.status.modbus_address
                + register_width(config.status.modbus_data_type),
            )
        )
    if config.telemetry.enabled:
        used = occupied.setdefault(config.telemetry.register_type, set())
        telemetry_indexes = {
            config.telemetry.last_error_code_address,
            config.telemetry.success_counter_address,
            config.telemetry.timeout_counter_address,
            config.telemetry.protocol_error_counter_address,
            config.telemetry.poll_cycle_counter_address,
        }
        overlap = used.intersection(telemetry_indexes)
        if overlap:
            raise ValueError(
                "telemetry mapping overlaps existing register at "
                f"{config.telemetry.register_type}:{min(overlap)}"
            )
        used.update(telemetry_indexes)
    for point in config.points:
        if point.bus not in bus_names:
            raise ValueError(f"unknown bus for {point.name}: {point.bus}")
        if not (1 <= point.device <= MAX_DEVICES_PER_BUS):
            raise ValueError(
                f"invalid device number for {point.name}: "
                f"{point.device}, expected 1..{MAX_DEVICES_PER_BUS}"
            )
        if point.address < 0 or point.address > 2047:
            raise ValueError(f"invalid OVEN address for {point.name}: {point.address}")
        if point.protocol_format not in VALID_PROTOCOL_FORMATS:
            raise ValueError(
                f"unsupported protocol_format for {point.name}: {point.protocol_format}"
            )
        if point.register_type not in VALID_REGISTER_TYPES:
            raise ValueError(
                f"unsupported register_type for {point.name}: {point.register_type}"
            )
        if point.modbus_data_type not in VALID_MODBUS_DATA_TYPES:
            raise ValueError(
                f"unsupported modbus_data_type for {point.name}: {point.modbus_data_type}"
            )
        if point.modbus_address < 0:
            raise ValueError(f"modbus_address must be >= 0 for {point.name}")
        if point.time_mark_address is not None and point.time_mark_address < 0:
            raise ValueError(f"time_mark_address must be >= 0 for {point.name}")
        if (
            point.channel_status_address is not None
            and point.channel_status_address < 0
        ):
            raise ValueError(f"channel_status_address must be >= 0 for {point.name}")

        used = occupied.setdefault(point.register_type, set())
        width = register_width(point.modbus_data_type)
        indexes = set(range(point.modbus_address, point.modbus_address + width))
        if point.time_mark_address is not None:
            indexes.add(point.time_mark_address)
        if point.channel_status_address is not None:
            indexes.add(point.channel_status_address)
        overlap = used.intersection(indexes)
        if overlap:
            raise ValueError(
                f"overlapping Modbus mapping for {point.name} at "
                f"{point.register_type}:{min(overlap)}"
            )
        used.update(indexes)
        devices_per_bus[point.bus].add(point.device)

    total_devices = sum(len(devices) for devices in devices_per_bus.values())
    if total_devices > MAX_TOTAL_DEVICES:
        raise ValueError(
            f"configured devices exceed total limit: {total_devices} > {MAX_TOTAL_DEVICES}"
        )
    for bus_name, devices in devices_per_bus.items():
        if len(devices) > MAX_DEVICES_PER_BUS:
            raise ValueError(
                f"configured devices on {bus_name} exceed per-bus limit: "
                f"{len(devices)} > {MAX_DEVICES_PER_BUS}"
            )


def _load_buses(payload: dict[str, object]) -> list[BusConfig]:
    if "buses" in payload:
        raw_buses = payload["buses"]
        if not isinstance(raw_buses, list) or not raw_buses:
            raise ValueError("buses must be a non-empty list")
        return [
            BusConfig(
                name=entry["name"],
                serial=SerialConfig(**entry["serial"]),
                poll_interval_ms=entry["poll_interval_ms"],
            )
            for entry in raw_buses
        ]

    return [
        BusConfig(
            name="bus1",
            serial=SerialConfig(**payload["serial"]),
            poll_interval_ms=payload["poll_interval_ms"],
        )
    ]


def _load_point(entry: dict[str, object], buses: list[BusConfig]) -> PointConfig:
    point_data = dict(entry)
    if "bus" not in point_data:
        point_data["bus"] = buses[0].name
    if "device" not in point_data:
        point_data["device"] = 1
    return PointConfig(**point_data)


def _validate_serial_config(bus_name: str, serial: SerialConfig) -> None:
    if serial.bytesize not in {7, 8}:
        raise ValueError(f"bus {bus_name}: serial.bytesize must be 7 or 8")
    if serial.parity not in {"N", "E", "O"}:
        raise ValueError(f"bus {bus_name}: serial.parity must be N, E or O")
    if serial.stopbits not in {1, 2}:
        raise ValueError(f"bus {bus_name}: serial.stopbits must be 1 or 2")
    if serial.timeout_ms <= 0:
        raise ValueError(f"bus {bus_name}: serial.timeout_ms must be > 0")
    if serial.address_bits not in {8, 11}:
        raise ValueError(f"bus {bus_name}: serial.address_bits must be 8 or 11")


def _default_status_config() -> dict[str, object]:
    return {
        "enabled": True,
        "register_type": "holding_register",
        "modbus_address": 1,
        "modbus_data_type": "uint16",
    }


def _default_telemetry_config() -> dict[str, object]:
    return {
        "enabled": True,
        "register_type": "holding_register",
        "last_error_code_address": 2,
        "success_counter_address": 3,
        "timeout_counter_address": 4,
        "protocol_error_counter_address": 5,
        "poll_cycle_counter_address": 6,
    }


def _default_health_config() -> dict[str, object]:
    return {
        "stale_after_cycles": 3,
        "fault_after_failures": 10,
        "recovery_poll_interval_cycles": 5,
    }
