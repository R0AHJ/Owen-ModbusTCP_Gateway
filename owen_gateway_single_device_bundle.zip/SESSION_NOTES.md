# Session Notes

## Current State

Project is reduced to the `OWEN RS-485 -> Modbus-TCP` scenario.

The single-device path for `OVEN TRM138` is working.

Confirmed working setup:

- device: `OVEN TRM138`
- serial: `9600 8N1`
- base address: `96`
- OVEN network addressing mode: `8-bit`
- port used during validation: `COM6`

## Key Fixes Already Made

- Removed obsolete OPC gateway code.
- Repaired local Python environment and PyCharm interpreter setup.
- Fixed `pymodbus 3.8.6` compatibility in the Modbus server layer.
- Fixed OVEN address encoding:
  - config addresses like `96..103` are `8-bit` OVEN addresses
  - protocol frame now expands them to full network address form
- Added support for `rEAd` payloads returned by `TRM138`:
  - `float32` value
  - optional 2-byte time mark suffix
- Added single-device diagnostic probe:
  - module: `owen_gateway.probe`
  - config: `owen_probe.com6.json`

## Confirmed Device Behaviour

- Channels `96, 97, 98, 99, 100, 101, 103` respond correctly to `rEAd`.
- Channel `102` returns empty payload.
- Empty payload is treated as valid `disabled/no-data`, not as a communication failure.

## Main Files To Use

- single device gateway config:
  - `owen_config.single_trm138.com6.json`
- simplified example config:
  - `owen_config.example.json`
- diagnostic probe config:
  - `owen_probe.com6.json`

## Channel Quality Logic

Implemented in gateway:

- up to `3` consecutive unchanged time marks are acceptable
- after that, channel status becomes `stale`
- after `10` consecutive failed polls, channel status becomes `failed`
- failed channel is then polled less frequently

Channel status codes:

- `0` - disabled / no data / empty payload
- `1` - ok
- `2` - stale
- `3` - temporary communication error
- `4` - protocol error
- `5` - failed, reduced polling

## Modbus Map For Single TRM138

Service telemetry:

- `HR1` - gateway status
- `HR2` - last error code
- `HR3` - success counter
- `HR4` - timeout counter
- `HR5` - protocol error counter
- `HR6` - poll cycle counter

Channels:

- channel 1:
  - `HR16..HR17` value
  - `HR18` time mark
  - `HR19` channel status
- channel 2:
  - `HR20..HR21` value
  - `HR22` time mark
  - `HR23` channel status
- channel 3:
  - `HR24..HR25` value
  - `HR26` time mark
  - `HR27` channel status
- channel 4:
  - `HR28..HR29` value
  - `HR30` time mark
  - `HR31` channel status
- channel 5:
  - `HR32..HR33` value
  - `HR34` time mark
  - `HR35` channel status
- channel 6:
  - `HR36..HR37` value
  - `HR38` time mark
  - `HR39` channel status
- channel 7:
  - `HR40..HR41` value
  - `HR42` time mark
  - `HR43` channel status
- channel 8:
  - `HR44..HR45` value
  - `HR46` time mark
  - `HR47` channel status

## Commands

Probe one device:

```powershell
.\.venv\Scripts\python.exe -m owen_gateway.probe --config owen_probe.com6.json --log-level INFO
```

Run single-device gateway:

```powershell
.\.venv\Scripts\python.exe -m owen_gateway --config owen_config.single_trm138.com6.json --log-level INFO
```

Run tests:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests
```

## What To Remember On Another Computer

- do not copy `.venv`
- create a fresh virtual environment
- install from `requirements.txt`
- adjust only the serial port name if needed
- start with the probe first
